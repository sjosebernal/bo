function addPlaca() {
    const placaInput = document.getElementById('placaInput');
    const historyList = document.getElementById('historyList');

    if (placaInput.value) {
        const listItem = document.createElement('li');
        listItem.textContent = `Placa: ${placaInput.value}`;
        historyList.appendChild(listItem);
        placaInput.value = '';
        document.getElementById('message').style.display = 'block';
    } else {
        alert('Por favor, ingrese una placa.');
    }
}

function clearHistory() {
    const historyList = document.getElementById('historyList');
    historyList.innerHTML = '';
    document.getElementById('message').style.display = 'none';
}

document.getElementById('fileInput').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();

        reader.onload = function(e) {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            const json = XLSX.utils.sheet_to_json(sheet);

            // Mostrar el contenido del archivo Excel en la consola o procesarlo como prefieras
            console.log(json);
            alert('Archivo Excel cargado con éxito. Revisa la consola para más detalles.');
        };

        reader.readAsArrayBuffer(file);
    }
});
